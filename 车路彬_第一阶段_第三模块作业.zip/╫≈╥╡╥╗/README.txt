
请求路径：                                                   有访问权限的用户

http://localhost:8080/testSecurity01/handler01?username=            Tom

http://localhost:8080/testSecurity01/handler02?username=         Tom、Join


http://localhost:8080/testSecurity02/handler01?username=          Tom James

http://localhost:8080/testSecurity02/handler02?username=      无限制(Tom、Join、James)