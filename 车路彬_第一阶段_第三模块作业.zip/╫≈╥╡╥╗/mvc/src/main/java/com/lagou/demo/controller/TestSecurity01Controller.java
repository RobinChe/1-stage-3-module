package com.lagou.demo.controller;

import com.lagou.edu.mvcframework.annotations.LagouController;
import com.lagou.edu.mvcframework.annotations.LagouRequestMapping;
import com.lagou.edu.mvcframework.annotations.Security;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 这里是测试controller带有权限注解情况的api
 */
@LagouController
@LagouRequestMapping("/testSecurity01")
@Security({"Tom", "Join", " Tom ", " ", ""})
public class TestSecurity01Controller {


    /**
     * handler和 controller都有权限控制，取 交集
     * @param username
     * @return
     */
    @LagouRequestMapping("/handler01")
    @Security({"Tom", "James"})
    public void handler01(HttpServletResponse response, String username) throws IOException {
        System.out.println("进入到了TestSecurity01Controller_handler01:" + username);

        response.setCharacterEncoding("gbk");
        response.getWriter().write("进入到了TestSecurity01Controller_handler01:" + username);
    }

    /**
     * handler上没有，以 controller的权限控制为准
     * @param username
     * @return
     */
    @LagouRequestMapping("/handler02")
    public void handler02(HttpServletResponse response, String username) throws IOException {
        System.out.println("进入到了TestSecurity01Controller_handler02:" + username);

        response.setCharacterEncoding("gbk");
        response.getWriter().write("进入到了TestSecurity01Controller_handler02:" + username);
    }




}
