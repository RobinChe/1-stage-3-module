package com.lagou.demo.service;

public interface IDemoService {

    String get(String name);
}
