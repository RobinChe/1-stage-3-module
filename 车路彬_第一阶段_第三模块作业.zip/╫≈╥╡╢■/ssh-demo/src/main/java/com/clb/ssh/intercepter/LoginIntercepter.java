package com.clb.ssh.intercepter;

import com.clb.ssh.common.ConstantUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginIntercepter implements HandlerInterceptor {

    private Logger logger = LoggerFactory.getLogger(LoggerFactory.class);


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        logger.debug("执行handler前，进入到了登录拦截器.....");
        //获取请求的地址（根域名以外的部分）
        String uri = request.getRequestURI();
        if (uri.indexOf("/user/login") >= 0 ){
            return true;
        }
        //获取session，有就是说明已经登录，没有就是拦截访问并跳转到登录页面
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute(ConstantUtil.SESSION_USER_NAME);
        if (username != null && !"".equals(username)){
            return true;
        }
        //request.setAttribute("msg","还没登陆！快去登陆啊！");
        request.getRequestDispatcher("/WEB-INF/view/index.jsp").forward(request,response);
        return false;
    }
}
