package com.clb.ssh.service;

public interface ResumeService {



}
