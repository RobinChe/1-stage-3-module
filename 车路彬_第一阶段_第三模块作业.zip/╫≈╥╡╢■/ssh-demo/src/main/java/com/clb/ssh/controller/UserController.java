package com.clb.ssh.controller;

import com.clb.ssh.common.ConstantUtil;
import com.clb.ssh.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("/user")
public class UserController {

    private Logger logger = LoggerFactory.getLogger(UserController.class);
    /**
     * 登录页面
     * @return
     */
    @GetMapping("/login")
    public ModelAndView login() {
        return new ModelAndView("index");
    }


    @PostMapping("/login")
    public void doLogin(User user, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        logger.info("user" + user.getName());
        if(ConstantUtil.USER_NAME.equals(user.getName()) && ConstantUtil.USER_PASSWORD.equals(user.getPassword())) {
            request.getSession(true).setAttribute(ConstantUtil.SESSION_USER_NAME, user.getName());
            response.sendRedirect("/resume/list");
        } else {
            request.setAttribute("errorMessage", "用户名或密码不正确!");
            request.getRequestDispatcher("/WEB-INF/view/index.jsp").forward(request, response);
        }
    }

    @GetMapping("/out")
    public ModelAndView loginOut(HttpServletRequest request) {
        request.getSession().removeAttribute(ConstantUtil.SESSION_USER_NAME);
        return new ModelAndView("index");
    }


}
