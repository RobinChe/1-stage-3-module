package com.clb.ssh.dao;

import com.clb.ssh.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResumeDao extends JpaRepository<Resume, Long> {

}
