package com.clb.ssh.service.impl;

import com.clb.ssh.service.ResumeService;

public class ResumeServiceImpl implements ResumeService {


}
