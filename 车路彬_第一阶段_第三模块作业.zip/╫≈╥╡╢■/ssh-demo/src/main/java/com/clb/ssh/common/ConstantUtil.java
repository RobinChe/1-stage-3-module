package com.clb.ssh.common;

public class ConstantUtil {


    public static final String USER_NAME = "admin";
    public static final String USER_PASSWORD = "admin";

    public static final String SESSION_USER_NAME = "user_name";


}
